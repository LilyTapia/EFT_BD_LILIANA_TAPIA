-- Insertar datos en profesor_academia
INSERT INTO profesor_academia (id_profesor, id_academia, turno) 
VALUES (1, 1, 'Mañana');

INSERT INTO profesor_academia (id_profesor, id_academia, turno) 
VALUES (2, 1, 'Tarde');

INSERT INTO profesor_academia (id_profesor, id_academia, turno) 
VALUES (3, 2, 'Mañana');

INSERT INTO profesor_academia (id_profesor, id_academia, turno) 
VALUES (4, 2, 'Tarde');

INSERT INTO profesor_academia (id_profesor, id_academia, turno) 
VALUES (5, 3, 'Noche');

SELECT * FROM profesor_academia